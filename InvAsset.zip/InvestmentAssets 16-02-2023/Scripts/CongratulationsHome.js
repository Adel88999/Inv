﻿

async function GetCongrats() {
    showLoaderInsideControl('DivInnerLoader', 1);

    //global var
    congratslistItems = await CommonFunctions
        .CallWS(CommonFunctions.GetListItems, {
            listName: ListNames.Congratulations
            , itemLimit: 1000000
            , orderByField: "Date"
            , weburl: `${_spPageContextInfo.siteAbsoluteUrl + "/ar/announcements"}`
            , filter: "Publish eq 1"
        });

    var tempTRCards = _.map(congratslistItems, function (value, key) {
        return `<tr><td><div class="customCard">
                            <div class="customCard-image"><img src="1.jpg" alt=""></div>
                            <div class="customCard-info">
                                    <h3> ${CommonFunctions.GetValue(value.Title, value.Title_En)}</h3>
                               <p>${moment(value.Date).format('DD-MMM-YYYY')}</p>
                            </div>
                            <div class="card bg-primary"></div>
                        </div></td>
</tr>`;

    });
    /* - ${value.Date.split('T')[0]}*/
    var tempTableTrs = _.map(congratslistItems, function (value, key) {
        var title = CommonFunctions.GetValue(value.Title, value.Title_En);
        var details = CommonFunctions.GetValue(value.Details_Ar, value.Details_En);
        var dateStr = moment(value.Date).format('DD-MMM-YYYY');

        return `<tr>
                    <td>
                      <a href="javascript:;" onclick="ShowCongratDetails('${value.Id}')">
                        <span class="small calendar-text">
                          <svg class="icon icon-fill icon-xs mx-1">
                            <use xlink:href="#icon-clock"></use>
                          </svg>
                          <label>${dateStr}</label>
                        </span>
                        ${title}
                      </a>
                    </td>
                </tr>`;

    });

    $("#tblDataList").find('tbody').append(tempTableTrs);

    if (_spPageContextInfo.currentCultureLCID == 1025) {
        $('#tblDataList').DataTable({
            "language":
                DataTableLocalizationAr
        });
    } else {
        $("#tblDataList").DataTable();
    }

   
    $("#DivInnerLoader").html('');
    $("#tblDataList_previous").text(GetResourseValue('Previous'));
    $("#tblDataList_next").text(GetResourseValue('Next'));
}

$(document).ready(async function () {

    // showLoader();
    // hideLoader()

    //////////////////////

    GetCongrats();

    setTitleResourse('Congratulations', 'divInnerTitle');
    //$("#txtSear   ch").attr("placeholder", GetResourseValue('Search'));

});