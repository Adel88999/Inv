// import "./CommonFunctions";
// import _ from "./lodash.min.js";
// import { $pnp } from "./pnp.min.js";



function setWelcomeUser() {
    //_spPageContextInfo.userDisplayName
    $("#lblWelcome").text(GetResourseValue('Welcome'))
    $("#lblUserDisplayName").text(_spPageContextInfo.userDisplayName)
}

async function GetQuickLinks() {
    showLoaderInsideControl('mainMenu', 6);
    var listItems = await CommonFunctions.CallWS(CommonFunctions.GetListItems,
        {
            listName: SiteLists.QuickLinksList.Name,
            orderByField: "ShowOrder",
            orderByAsc: true,
            weburl: `${_spPageContextInfo.siteAbsoluteUrl + SiteLists.QuickLinksList.Path}`
        });

    var temp = _.map(listItems, function (value, key) {
        var title = CommonFunctions.GetValue(value.Title, value.Title_En);
        var linkUrl = CommonFunctions.GetValue(value.URL_Ar.Url, value.URL_En.Url);

        return `<li class="nav-item">
                            <a href="${linkUrl}" class="nav-link" onclick="showLoader()">
                                ${title}
                                ${value.Is_New == true ? `<span class="badge badge-coral-red rounded m-1">${CommonFunctions.GetValue("جديد", "New")}</span>` : ""}
                            </a>
                        </li>`;

    });
    $("#mainMenu").html(temp);
}

$(document).ready(function () {

    $("body").prepend(divModalAlertHtml);
    $("body").prepend(divMainLoaderHtml);

    if (_spPageContextInfo.currentCultureLCID == 1025) {
        moment.locale("ar-sa");
    } else {
        moment.locale("en-us");
    }

    showLoaderInsideControl('mainMenu', 6);

    let GetGroups = async function () {

        //  var listItems=  await CommonFunctions.GetListItems({listName:ListNames.GroupsList,weburl:_spPageContextInfo.siteAbsoluteUrl+"/ar"});
        var listItems = await CommonFunctions.CallWS(CommonFunctions.GetListItems,
            {
                listName: SiteLists.GroupsList.Name,
                weburl: _spPageContextInfo.siteAbsoluteUrl + SiteLists.GroupsList.Path
            });

        var temp = _.map(listItems, function (value, key) {
            return `<option data-url="${CommonFunctions.GetValue(value.Group_URL.Url, value.Group_URL_En.Url)}">${CommonFunctions.GetValue(value.Title, value.Title_En)}</option>`;

        });

        $("#ddl_Groups").html(temp);
        $("#ddl_Groups").change(function () {
            showLoader();
            window.location.href = $(this).find(":selected").data("url");
        });
    };

    GetGroups();
    setWelcomeUser();

    GetQuickLinks();

    setTitleResourse('AICAlinmaCalendar', 'divAICAlinmaCalendar');
    setTitleResourse('GroupSelector', 'lblGrouupSelector');
    setTitleResourse('LastLogin', 'lblLoginTimeText');

    //var timeVar = formatDate(new Date,true);
     SetLoginTimeToday('spanTime');

});


