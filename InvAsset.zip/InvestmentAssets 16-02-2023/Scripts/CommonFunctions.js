﻿function SetLoginTimeToday(controlId) {
    var dayVar = localStorage.getItem('Day');
    var timeVar = localStorage.getItem('Time');
    var currentDate = new Date();

    if (!dayVar && dayVar == undefined || dayVar == 'undefined' || dayVar == null
        || !timeVar && timeVar == undefined || timeVar == 'undefined' || timeVar == null
        || (dayVar && dayVar != currentDate.getDate())) {

        localStorage.setItem('Day', currentDate.getDate());
      

        var hours = ("0" + currentDate.getHours()).slice(-2);
        var minutes = ("0" + currentDate.getMinutes()).slice(-2)
        var ampm = hours >= 12 ? 'pm' : 'am';
        timeVar = hours + ':' + minutes + ' ' + ampm;
        localStorage.setItem('Time', timeVar);
        
    } 
    $("#" + controlId).html( timeVar); 
}

function formatDate(date, includeTime) {
    if (_spPageContextInfo.currentCultureLCID == 1025) {
        moment.locale("ar-sa");
    }
    if (!date) {
        date = new Date();
    }
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    if (includeTime == true) {
        return date.getMonth() + 1 + "/" + date.getDate() + "/" + date.getFullYear() + " " + strTime;
    } else {
        return date.getMonth() + 1 + "/" + date.getDate() + "/" + date.getFullYear();
    }

}

function ConvertDateFromJsonObj(jsonDate) {
    return new Date(jsonDate.match(/\d+/)[0] * 1);
}

function ShowModalAlert({ title, body, showCloseBtnHeader, showLarge, btnCloseHref, headerBGColor, ImagePath }) {

    if (body) {
        $("#divModalAlertBody").html(body);
    } else {
        $("#divModalAlertBody").html('');
    }

    if (title) {
        $("#divModalAlertHeaderTitle").text(title);
    } else {
        $("#divModalAlertHeaderTitle").text('');
    }


    if (showCloseBtnHeader == true) {
        $("#btnModalAlertCloseInHeader").show();
    } else {
        $("#btnModalAlertCloseInHeader").hide();
    }

    if (headerBGColor) {
        $("#divModalAlertHeader").css('background', headerBGColor);
    } else {
        $("#divModalAlertHeader").css('background', '#8C4188');
    }

    if (showLarge == true) {
        $("#divModalAlertDialog").addClass('modal-lg');
    } else {
        $("#divModalAlertDialog").removeClass('modal-lg');
    }

    if (btnCloseHref) {
        $("#btnModalAlertClose").on("click", function () {
            $("#divModalAlert").modal('hide');
            window.location.href(btnModalAlertClose);
        })
    } else {
        $("#btnModalAlertClose").on("click", function () {
            $("#divModalAlert").modal('hide');
        })
    }

    if (ImagePath) {
        $("#imgModalAlertBody").show();
        $("#imgModalAlertBody").attr('src', ImagePath);

    } else {
        $("#imgModalAlertBody").hide();
        $("#imgModalAlertBody").attr('src', '');
    }
    $("#btnModalAlertClose").text(GetResourseValue('close'));

    $("#divModalAlert").modal('show');
}

function HideModalAlert() {
    $("#divModalAlert").modal('hide');
    $("#divModalAlertBody").text('');
    $("#divModalAlertHeaderTitle").text('');
    $("#divModalAlertHeader").css('background', '#8C4188');
}

function ShowCongratDetails(itemId) {
    var items = congratslistItems.filter(x => x.Id == itemId);
    //console.log(items);
    if (items && items.length > 0) {

        var title = CommonFunctions.GetValue(items[0].Title, items[0].Title_En);
        var type = CommonFunctions.GetValue(items[0].Type_Ar, items[0].Type_En);
        var alertTitle = GetResourseValue('Congratulation');
        var imagePath;

        if (type) {
            alertTitle += ` ${type}`;
        }

        if (items[0].Type_En && items[0].Type_En.toLowerCase().indexOf('born') > -1) {
            var new_Born_Gender = CommonFunctions.GetValue(items[0].New_Born_Gender_Ar, items[0].New_Born_Gender_En);
            if (new_Born_Gender) {
                alertTitle += ` (${new_Born_Gender})`;
            }
            imagePath = CongratsBirth_smImagePath;
        } else if (items[0].Type_En && items[0].Type_En.toLowerCase().indexOf('marriage') > -1) {
            imagePath = CongratsMarriage2023_smImagePath;
        }

        var details = CommonFunctions.GetValue(items[0].Details_Ar, items[0].Details_En);
        var dateStr = moment(items[0].Date).format('DD-MMM-YYYY');

        ShowModalAlert({ title: alertTitle, body: title + '<br/>' + dateStr + '<br/>' + details, showCloseBtnHeader: false, showLarge: true, headerBGColor: '#8C4188', ImagePath: imagePath })
    } else {
        var SelectItemFirst = GetResourseValue('SelectItemFirst');
        ShowModalAlert({ title: '', body: SelectItemFirst, showCloseBtnHeader: false, showLarge: false })
    }
}

function ShowCondolencesDetails(itemId) {
    var items = condolencesListItems.filter(x => x.Id == itemId);
    //console.log(items);
    if (items && items.length > 0) {

        var title = CommonFunctions.GetValue(items[0].Title, items[0].Title_En);
        var type = items[0].RelativeRelation;
        var alertTitle = GetResourseValue('Condolence');

        if (type) {
            var typeArr = type.split('-');
            if (typeArr.length == 2) {
                var typePendingOnLang = CommonFunctions.GetValue(typeArr[0], typeArr[1]);
                if (typePendingOnLang) {
                    alertTitle += ` (${typePendingOnLang.replace(/\s/g, '')}) `;
                }
            }
        }

        var details = CommonFunctions.GetValue(items[0].Details_Ar, items[0].Details_En);
        var dateStr = moment(items[0].Date).format('DD-MMM-YYYY');

        ShowModalAlert({ title: alertTitle, body: title + '<br/>' + dateStr + '<br/>' + details, showCloseBtnHeader: false, showLarge: false, headerBGColor: '#454545' })
    } else {
        var SelectItemFirst = GetResourseValue('SelectItemFirst');
        ShowModalAlert({ title: '', body: SelectItemFirst, showCloseBtnHeader: false, showLarge: false })
    }
}

function goToListHomePage(CatName) {
    var subsite = '';
    if (_spPageContextInfo.currentCultureLCID == 1025) {
        subsite = "/ar";
    } else {
        subsite = "/en";
    }
    var newHref = window.location.origin + subsite;
    if (CatName == ListNames.Congratulations) {
        window.location.href = newHref + "/Announcements/Pages/CongratulationsHome.aspx";
    } else if (CatName == ListNames.AnnouncementsList) {
        window.location.href = newHref + "/Announcements/Pages/default.aspx";
    } else if (CatName == ListNames.Condolences) {
        window.location.href = newHref + "/Announcements/Pages/CondolencesHome.aspx";
    } else if (CatName == ListNames.NewsList) {
        window.location.href = newHref + "/News/Pages/default.aspx";
    } else if (CatName == "Forms") {
        window.location.href = newHref + "/Pages/Forms.aspx";
    } else if (CatName == "Procedures") {
        window.location.href = newHref + "/Pages/Forms.aspx?FormTypeId=2";
    }
}

function getParameterByName(name, url) {
    if (!url) {
        url = window.location.href
    }
    if (name) {
        name = name.toLowerCase().replace(/[\[\]]/g, '\\$&');
        var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
            results = regex.exec(url.toLowerCase());
        if (!results) return '';
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }
    return '';
}

function showLoader() {
    document.getElementById("divMainLoader").style.width = "100%";
}

function hideLoader() {
    document.getElementById("divMainLoader").style.width = "0%";
}

function RedirectToArabic() {
    showLoader();
    if (window.location.href.toLowerCase().indexOf('/en') > -1) {
        window.location.href = window.location.href.toLowerCase().replace('/en', '/ar')//window.location.origin + '/ar' + window.location.pathname;
    } else {
        window.location.href = window.location.href + 'ar';
    }

    //window.location.href = window.location.origin + '/ar';
}

function RedirectToEnglish() {
    showLoader();
    window.location.href = window.location.href.toLowerCase().replace('/ar', '/en')
    // window.location.href = window.location.origin;
}

function GetResourseValue(key) {
    return _spPageContextInfo.currentCultureLCID == 1025
        ? resourseAr[key]
        : resourseEn[key];


}

function setTitleResourse(key, controlId) {
    $("#" + controlId).text(GetResourseValue(key));
}

function SetClassAttribute(className, attrName, value) {
    $("." + className).attr(attrName, value);
}

function SetControlAttribute(controlId, attrName, value) {
    $("#" + controlId).attr(attrName, value);
}

function showLoaderInsideControl(controlId, brNum) {
    var brhtml = '';
    if (brNum && brNum > 0) {
        for (var i = 0; i < brNum; i++) {
            brhtml += '<br/>';
        }
    }
    $("#" + controlId).html(brhtml + '<div class="cssload-container">	<div class="cssload-whirlpool"></div><div></div><br/><br/>');//'<div class="overlay">    <div class="overlay-content">    <div class="spinner-border text-info" role="status" style="width:100px;height:100px">  <span class="sr-only">Loading...</span></div>');
}

function emptyControlHtml(controlId) {
    $("#" + controlId).html('');
}

function changeDirection(dir) {
    $('body').css('direction', dir)
}

function getExtension(fileName) {
    if (fileName) {
        return fileName.substr((fileName.lastIndexOf('.') + 1))
    }
    return '';

}
var carouselIndex = 0;

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    carouselIndex++;
    if (carouselIndex > x.length) { carouselIndex = 1 }
    x[carouselIndex - 1].style.display = "block";
    setTimeout(carousel, 4000); // Change image every 2 seconds
}

function AjaxRequest(fnSuccess, fnBeforeSend, fnComplete, fnError, { listName, listPath, filter, selectFields, loaderDivId, showEmpty, showError }) {
    var select_Filter = '';
    if (selectFields) {
        select_Filter = `?${selectFields}`;
    }
    if (filter) {
        if (select_Filter.length > 0) {
            select_Filter += '&';
        } else {
            select_Filter += '?';
        }
        select_Filter += filter;
    }
    var urlRequest = `${_spPageContextInfo.siteAbsoluteUrl + listPath}/_api/web/lists/getbytitle('${listName}')/Items${select_Filter}`;
    $.ajax({
        url: urlRequest,
        type: "GET",
        headers: { "accept": "application/json;odata=verbose" },
        dataType: 'json',
        beforeSend: function () {
            if (loaderDivId) {
                showLoaderInsideControl(loaderDivId)
            }
            if (fnBeforeSend) {
                fnBeforeSend;
            }
        },
        complete: function () {
            //if (loaderDivId) {
            //    emptyControlHtml(loaderDivId)
            //}
            if (fnComplete) {
                fnComplete;
            }
        },
        success: function (data) {
            //if (data.d.results) {
            //    // TODO: handle the data
            //    return data;
            //    console.log(data.d.results[0].FileRef);
            //}
            if (fnSuccess) {
                fnSuccess(data);
            }
            if (data && data.d && data.d.results && data.d.results.length > 0 && data.d.results[0]) {

            } else if (showEmpty && showEmpty == true && loaderDivId) {
                var warning = divWarning.replace('_message_', GetResourseValue('NoData'))
                $("#" + loaderDivId).html(warning);
            }

        },
        error: function (xhr) {
            console.log(listName);
            console.log(urlRequest);
            console.log(xhr.status + ': ' + xhr.statusText);
            if (fnError) {
                fnError;
            }
            if (showError && showError == true && loaderDivId) {
                var warning = divWarning.replace('_message_', GetResourseValue('CommonErrorTryLater'))
                $("#" + loaderDivId).html(warning);
            } else if (loaderDivId) {
                emptyControlHtml(loaderDivId)
            }
        }
    });

    //var value = $('#RegiondID').val();
    //$.ajax({
    //    url: sitePath + '/Home/GetCities',
    //    type: 'GET',
    //    cache: false,
    //    data: { regionID: value },
    //    dataType: 'json',
    //    beforeSend: function () {
    //        $("#REAL_ESTATE_CITY").prop("disabled", true);
    //    },
    //    complete: function () {
    //        $("#REAL_ESTATE_CITY").prop("disabled", false);
    //        $("#REAL_ESTATE_CITY").prepend("<option value='' selected='selected'>" + application.messages.PleaseSelect + "</option>");
    //    },
    //    success: function (data) {
    //        if (data.length == 0) {
    //            $("#REAL_ESTATE_CITY").html("");
    //        } else {
    //            $("#REAL_ESTATE_CITY").html(data);
    //            //$("#DistrictID").select2("open");
    //        }
    //    },
    //    error: function (error) {
    //        $('#divErrorMessage').show();
    //        $('#txtErrorMsg').text('@Resources.Common.ExceptionError');
    //        $('#pleaseWaitDialog').modal('hide');
    //    }
    //});


}











class CommonFunctions {

    //if you need to do something before request
    static async CallWS(methodName, args) {
        //console.log("calling" + methodName.name);
        return await methodName(args);

    }

    //if you need to do something after request
    static ReturnFromWS(response) {

        //console.log("returning " + response);
        return response;
    }

    //
    static async GetListItems({ listName, orderByField = "Created", orderByAsc = false, itemLimit = 100, weburl = _spPageContextInfo.webAbsoluteUrl, filter }) {

        //debugger;
        var web = new $pnp.Web(weburl);
        var response;
        if (filter) {
            response = await web.lists.getByTitle(listName)
                .items
                .filter(filter)
                .top(itemLimit)
                .orderBy(orderByField, orderByAsc)
                //.usingCaching()
                .get().then(res => {
                    return res;
                });

        }
        else {
            return await web.lists.getByTitle(listName)
                .items
                .top(itemLimit)
                .orderBy(orderByField, orderByAsc)
                //.usingCaching()
                .get().then(res => {
                    return res;
                });
        }

        return CommonFunctions.ReturnFromWS(response);
    }

    //
    static async GetRootFolders({ listName, orderByField = "TimeCreated", orderByAsc = false, itemLimit = 100, weburl = _spPageContextInfo.webAbsoluteUrl, filter }) {

        //debugger;
        //$pnp.sp.web.lists.getByTitle("ImageGallery").rootFolder.folders.filter("Name ne 'Forms'").get()
        var web = new $pnp.Web(weburl);
        var response;
        if (filter) {
            response = await web.lists.getByTitle(listName)
                .rootFolder.folders
                .filter(filter)
                .top(itemLimit)
                .orderBy(orderByField, orderByAsc)
                //.usingCaching()
                .get().then(res => {
                    return res;
                });

        }
        else {
            response = await web.lists.getByTitle(listName)
                .rootFolder.folders
                .top(itemLimit)
                .orderBy(orderByField, orderByAsc)
                //.usingCaching()
                .get().then(res => {
                    return res;
                });
        }

        return CommonFunctions.ReturnFromWS(response);


    }

    static async GetFolderImages({ listName, orderByField = "TimeCreated", orderByAsc = false, itemLimit = 500, weburl = _spPageContextInfo.webAbsoluteUrl, filter }) {

        //debugger;


        var web = new $pnp.Web(weburl);
        var response;
        if (filter) {
            response = await web.getFolderByServerRelativeUrl(listName)
                .files
                .expand('Files/ListItemAllFields')
                .select('Title,Name,ServerRelativeUrl')
                .filter(filter)
                .top(itemLimit)
                .orderBy(orderByField, orderByAsc)
                //.usingCaching()
                .get().then(res => {
                    return res;
                });

        }
        else {
            response = await web.getFolderByServerRelativeUrl(listName)
                .files
                .expand('Files/ListItemAllFields')
                .select('Title,Name,ServerRelativeUrl')
                .top(itemLimit)
                .orderBy(orderByField, orderByAsc)
                //.usingCaching()
                .get().then(res => {
                    return res;
                });
        }

        return CommonFunctions.ReturnFromWS(response);


    }

    static GetValue(ArValue, EnValue) {
        return _spPageContextInfo.currentCultureLCID == 1025 ? ArValue : EnValue;

    }

}

