﻿
async function GetAnnouncementDetails(itemId) {
    showLoaderInsideControl('DivInnerLoader', 1);

    listItem = await CommonFunctions
        .CallWS(CommonFunctions.GetListItems, {
            listName: ListNames.AnnouncementsList
            , itemLimit: 1
            , orderByField: "Date"
            , weburl: `${_spPageContextInfo.siteAbsoluteUrl + "/ar/announcements"}`
            //, filter: "Publish eq 1 and ID eq " + itemId
            , filter: "ID eq " + itemId
        });

    //console.log(listItem);
    if (listItem && listItem.length > 0) {
        var title = CommonFunctions.GetValue(listItem[0].Title, listItem[0].Title_En);
        var details = CommonFunctions.GetValue(listItem[0].Details_Ar, listItem[0].Details_En);
        var dateStr = moment(listItem[0].Date).format('DD-MMM-YYYY');

        $("#hTitle").html(title);
        $("#lblDate").html(dateStr);
        $("#divBody").html(details);
    } else {
        NoDate();
    }
    //check if attachments exists :build table body and show table
    // $("#tblAttachments").show();
}

function NoDate() {
    $("#spanDate").hide();
    $("#hTitle").html('');
    $("#lblDate").html('');
    $("#divBody").html(divWarning.replace('_message_', GetResourseValue('NoData')));
}

$(document).ready(async function () {
    showLoaderInsideControl('divBody');
    var itemId = getParameterByName("DetailsId");
    if (!itemId) {
        //no data to show
        NoDate();
    } else {
        GetAnnouncementDetails(itemId);
    }
});