$(document).ready(function(){
	var datePickerLanguage;
	if($('body').css('direction') == 'ltr') {
		datePickerLanguage = '';
	}
	else {
		datePickerLanguage = 'ar';
	}

	var eventDates = {
		dates:[{
			type: 'vacation',
			date:'09/01/2019'
		}, {
			type: 'vacation',
			date:'09/02/2019'
		}, {
			type: 'vacation',
			date:'09/03/2019'
		}, {
			type: 'vacation',
			date:'09/04/2019'
		}, {
			type: 'vacation',
			date:'09/05/2019'
		}, {
			type: 'important-event',
			date:'09/23/2019'
		}]
	};

	var Event = function(type) {
		this.type = type;
	};

	var events = {};
	for(var i=0; i<eventDates.dates.length; i++) {
		events[new Date(eventDates.dates[i].date)] = new Event(eventDates.dates[i].type);
	}

	$.datepicker.setDefaults( $.datepicker.regional[ datePickerLanguage ] );
	$('#events_calendar').datepicker({
		showOtherMonths: true,
		dateFormat: 'dd mm yy',
        beforeShowDay: function( date ) {
			var event = events[date];
			if (event) {
				return [true, event.type, '']
			}
			else {
				return [true, '', ''];
			}
		}
	});
});