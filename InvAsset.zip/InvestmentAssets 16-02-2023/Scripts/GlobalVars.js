var congratslistItems = [];

var condolencesListItems = [];

const CongratsBirth_smImagePath = "/_LAYOUTS/15/InvestmentAssets/Images/CongratsBirth_sm.jpg";

const CongratsMarriage2023_smImagePath = "/_LAYOUTS/15/InvestmentAssets/Images/CongratsMarriage2023_sm.jpg";

const Press2023_smImagePath = "/_LAYOUTS/15/InvestmentAssets/Images/Press2023_sm.jpg";

const announcementTempPath = "/_LAYOUTS/15/InvestmentAssets/Images/announcement Temp.jfif";

const divModalAlertHtml = `<div id="divModalAlert" class="modal fade" role="dialog">
		    <div class="modal-dialog" id="divModalAlertDialog">
		        <!-- Modal content-->
		        <div class="modal-content">
		            <div class="modal-header" style="background:#6B989C" id="divModalAlertHeader">
		                <button type="button" class="close" data-dismiss="modal" id="btnModalAlertCloseInHeader" style="display:none">&times;</button>
		                <h4 class="modal-title" id="divModalAlertHeaderTitle" >Modal Header</h4>
		            </div>
		            <div class="modal-body" id="divModalAlertBodyMain">
                        <div clsss="text-center">
                            <image id="imgModalAlertBody" src="" style="diplay:none"/>
                        </div>
		                <div id="divModalAlertBody">Some text in the modal.</div>
		            </div>
		            <div class="modal-footer">
		                <button type="button" class="btn btn-default" data-dismiss="modal" id="btnModalAlertClose">إغلاق</button>
		            </div>
		        </div>
	   	 	</div>
		</div>
`;

const divMainLoaderHtml = `<div id="divMainLoader" class="overlay">
            <div class="overlay-content">
                <div class="spinner-border text-light" role="status" style="width:100px;height:100px"> <span class="sr-only">Loading...</span> </div>
            </div>
        </div>

`;

const divWarning = `<div  class="alert-warning text-center text-bold">
<br/>
           _message_
<br/>
<br/>
        </div>

`;

const divInfo = `<div  class="alert-Info text-center text-bold">
<br/>
           _message_
<br/>
<br/>
        </div>

`;

const divDanger = `<div  class="alert-danger text-center text-bold">
<br/>
           _message_
<br/>
<br/>
        </div>

`;

const divSuccess = `<div  class="alert-success text-center text-bold">
<br/>
           _message_
<br/>
<br/>
        </div>

`;

const DataTableLocalizationAr =
{
    "loadingRecords": "جارٍ التحميل...",
    "lengthMenu": "أظهر _MENU_ مدخلات",
    "zeroRecords": "لم يعثر على أية سجلات",
    "info": "إظهار _START_ إلى _END_ من أصل _TOTAL_ مدخل",
    "search": "ابحث:",
    "paginate": {
        "first": "الأول",
        "previous": "السابق",
        "next": "التالي",
        "last": "الأخير"
    },
    "aria": {
        "sortAscending": ": تفعيل لترتيب العمود تصاعدياً",
        "sortDescending": ": تفعيل لترتيب العمود تنازلياً"
    },
    "select": {
        "rows": {
            "_": "%d قيمة محددة",
            "1": "1 قيمة محددة"
        },
        "cells": {
            "1": "1 خلية محددة",
            "_": "%d خلايا محددة"
        },
        "columns": {
            "1": "1 عمود محدد",
            "_": "%d أعمدة محددة"
        }
    },
    "buttons": {
        "print": "طباعة",
        "copyKeys": "زر <i>ctrl<\/i> أو <i>⌘<\/i> + <i>C<\/i> من الجدول<br>ليتم نسخها إلى الحافظة<br><br>للإلغاء اضغط على الرسالة أو اضغط على زر الخروج.",
        "pageLength": {
            "-1": "اظهار الكل",
            "_": "إظهار %d أسطر",
            "1": "اظهار سطر واحد"
        },
        "collection": "مجموعة",
        "copy": "نسخ",
        "copyTitle": "نسخ إلى الحافظة",
        "csv": "CSV",
        "excel": "Excel",
        "pdf": "PDF",
        "colvis": "إظهار الأعمدة",
        "colvisRestore": "إستعادة العرض",
        "copySuccess": {
            "1": "تم نسخ سطر واحد الى الحافظة",
            "_": "تم نسخ %ds أسطر الى الحافظة"
        },
        "createState": "تكوين حالة",
        "removeAllStates": "ازالة جميع الحالات",
        "removeState": "ازالة حالة",
        "renameState": "تغيير اسم حالة",
        "savedStates": "الحالات المحفوظة",
        "stateRestore": "استرجاع حالة",
        "updateState": "تحديث حالة"
    },
    "searchBuilder": {
        "add": "اضافة شرط",
        "clearAll": "ازالة الكل",
        "condition": "الشرط",
        "data": "المعلومة",
        "logicAnd": "و",
        "logicOr": "أو",
        "value": "القيمة",
        "conditions": {
            "date": {
                "after": "بعد",
                "before": "قبل",
                "between": "بين",
                "empty": "فارغ",
                "equals": "تساوي",
                "notBetween": "ليست بين",
                "notEmpty": "ليست فارغة",
                "not": "ليست "
            },
            "number": {
                "between": "بين",
                "empty": "فارغة",
                "equals": "تساوي",
                "gt": "أكبر من",
                "lt": "أقل من",
                "not": "ليست",
                "notBetween": "ليست بين",
                "notEmpty": "ليست فارغة",
                "gte": "أكبر أو تساوي",
                "lte": "أقل أو تساوي"
            },
            "string": {
                "not": "ليست",
                "notEmpty": "ليست فارغة",
                "startsWith": " تبدأ بـ ",
                "contains": "تحتوي",
                "empty": "فارغة",
                "endsWith": "تنتهي ب",
                "equals": "تساوي",
                "notContains": "لا تحتوي",
                "notStartsWith": "لا تبدأ بـ",
                "notEndsWith": "لا تنتهي بـ"
            },
            "array": {
                "equals": "تساوي",
                "empty": "فارغة",
                "contains": "تحتوي",
                "not": "ليست",
                "notEmpty": "ليست فارغة",
                "without": "بدون"
            }
        },
        "button": {
            "0": "فلاتر البحث",
            "_": "فلاتر البحث (%d)"
        },
        "deleteTitle": "حذف فلاتر",
        "leftTitle": "محاذاة يسار",
        "rightTitle": "محاذاة يمين",
        "title": {
            "0": "البحث المتقدم",
            "_": "البحث المتقدم (فعال)"
        }
    },
    "searchPanes": {
        "clearMessage": "ازالة الكل",
        "collapse": {
            "0": "بحث",
            "_": "بحث (%d)"
        },
        "count": "عدد",
        "countFiltered": "عدد المفلتر",
        "loadMessage": "جارِ التحميل ...",
        "title": "الفلاتر النشطة",
        "showMessage": "إظهار الجميع",
        "collapseMessage": "إخفاء الجميع",
        "emptyPanes": "لا يوجد مربع بحث"
    },
    "infoThousands": ",",
    "datetime": {
        "previous": "السابق",
        "next": "التالي",
        "hours": "الساعة",
        "minutes": "الدقيقة",
        "seconds": "الثانية",
        "unknown": "-",
        "amPm": [
            "صباحا",
            "مساءا"
        ],
        "weekdays": [
            "الأحد",
            "الإثنين",
            "الثلاثاء",
            "الأربعاء",
            "الخميس",
            "الجمعة",
            "السبت"
        ],
        "months": [
            "يناير",
            "فبراير",
            "مارس",
            "أبريل",
            "مايو",
            "يونيو",
            "يوليو",
            "أغسطس",
            "سبتمبر",
            "أكتوبر",
            "نوفمبر",
            "ديسمبر"
        ]
    },
    "editor": {
        "close": "إغلاق",
        "create": {
            "button": "إضافة",
            "title": "إضافة جديدة",
            "submit": "إرسال"
        },
        "edit": {
            "button": "تعديل",
            "title": "تعديل السجل",
            "submit": "تحديث"
        },
        "remove": {
            "button": "حذف",
            "title": "حذف",
            "submit": "حذف",
            "confirm": {
                "_": "هل أنت متأكد من رغبتك في حذف السجلات %d المحددة؟",
                "1": "هل أنت متأكد من رغبتك في حذف السجل؟"
            }
        },
        "error": {
            "system": "حدث خطأ ما"
        },
        "multi": {
            "title": "قيم متعدية",
            "restore": "تراجع",
            "info": "القيم المختارة تحتوى على عدة قيم لهذا المدخل. لتعديل وتحديد جميع القيم لهذا المدخل، اضغط او انتقل هنا، عدا ذلك سيبقى نفس القيم",
            "noMulti": "هذا المدخل مفرد وليس ضمن مجموعة"
        }
    },
    "processing": "جارٍ المعالجة...",
    "emptyTable": "لا يوجد بيانات متاحة في الجدول",
    "infoEmpty": "يعرض 0 إلى 0 من أصل 0 مُدخل",
    "thousands": ".",
    "stateRestore": {
        "creationModal": {
            "columns": {
                "search": "إمكانية البحث للعمود",
                "visible": "إظهار العمود"
            },
            "toggleLabel": "تتضمن",
            "button": "تكوين الحالة",
            "name": "اسم الحالة",
            "order": "فرز",
            "paging": "تصحيف",
            "scroller": "مكان السحب",
            "search": "بحث",
            "searchBuilder": "مكون البحث",
            "select": "تحديد",
            "title": "تكوين حالة جديدة"
        },
        "duplicateError": "حالة مكررة بنفس الاسم",
        "emptyError": "لا يسمح بأن يكون اسم الحالة فارغة.",
        "emptyStates": "لا توجد حالة محفوظة",
        "removeConfirm": "هل أنت متأكد من حذف الحالة %s؟",
        "removeError": "لم استطع ازالة الحالة.",
        "removeJoiner": "و",
        "removeSubmit": "حذف",
        "removeTitle": "حذف حالة",
        "renameButton": "تغيير اسم حالة",
        "renameLabel": "الاسم الجديد للحالة %s:",
        "renameTitle": "تغيير اسم الحالة"
    },
    "autoFill": {
        "cancel": "إلغاء الامر",
        "fill": "املأ كل الخلايا بـ <i>%d<\/i>",
        "fillHorizontal": "تعبئة الخلايا أفقيًا",
        "fillVertical": "تعبئة الخلايا عموديا",
        "info": "تعبئة تلقائية"
    },
    "decimal": ",",
    "infoFiltered": "(مرشحة من مجموع _MAX_ مُدخل)",
    "searchPlaceholder": "مثال بحث"
}

const formsTableBodyTr = `
<tr>
    <td>_FormName_</td>
    <td>
        _FormDetails_
    </td>
    <td>
        <a href="_href_" class="d-block" target="blank">
            <svg class="icon icon-xs icon-fill d-inline">
                <use xlink:href="#icon-arrow-down"></use>
            </svg>
            _DownloadText_
            <span class="d-inline">_fileExtension_</span>
        </a>
    </td>
</tr>
`;
const formTableHead33 = `
 <tr class="bg-clay-brown text-white">
    <th style="width: 200px;">إسم النموذج</th>
    <th>الإجراءات والمتطلبات الإضافية</th>
    <th style="width: 125px;">التحميل</th>
</tr>
`;

const formTableHead = `
 <tr class="bg-clay-brown text-white">
    <th style="width: 200px;">_FormHeaderTitle_</th>
    <th>_FormHeaderDetails_</th>
    <th style="width: 125px;">_FormHeaderDownload_</th>
</tr>
`;

const formCardContainer = `
<div class="accordion accordion-spacing" id="accordionExample1">
_formCard_
</div>
`;

const formCard = `
<div class="card">
    <div class="card-header" id="headingOneExample_cardNo_">
        <h2 class="mb-0">
            <button class="btn btn-link _CardHeaderBtnClass_" type="button" data-toggle="collapse" data-target="#collapseOneExample_cardNo_" aria-expanded="_ariaExpanded_" aria-controls="collapseOneExample_cardNo_">
                _cardHeader_
                <div class="float-right">
                    <svg class="icon icon-sm icon-fill v-mirror">
                        <use xlink:href="#icon-chevron-down"></use>
                    </svg>
                </div>
            </button>
        </h2>
    </div>
    <div id="collapseOneExample_cardNo_" class="_CardCollapseClass_" aria-labelledby="headingOneExample_cardNo_" data-parent="#accordionExample1">
        <div class="card-body p-2">
            <table class="table table-bordered table-striped m-0">
                <thead>

                    _thead_

                </thead>
                <tbody>

                    _tbodyTrs_

                </tbody>
            </table>
        </div>
    </div>
</div>

`;

const offerBox = `
  <div class="Offerbox">
    <div class="boxImage">
      <img width="146" height="147" src="_boxImageURL_">
    </div>
    <div class="boxTitle">
      <a href="_DetailsURL_">_Title_</a>
    </div>
  </div>
`;

const offersBoxContainer = `
<div class="AnnouncemntCatDivContainer">
  <div class="AnnouncmentCatTitleDiv"><h2>_OfferCategoryTitle_</h2></div>
  _OfferBoxes_  
</div>
`;

const offersDetailsContainer = `
<div class="AnnouncemntCatDivContainer">
  <div class="AnnouncmentCatTitleDiv"><h2>_OfferTitle_</h2></div>
  <div class="AnnouncmentCatTitleDiv"><h2>_OfferCategoryTitle_</h2></div>
  <div> <img  src="_ImageURL_"></div>
  <div >_Details_</div>
</div>
`;

const calenderDetailsItemContainer = `
<div class="mb-3">
    <div>
        <span class="bg-fresh-mint d-inline-block mx-1 p-1"></span> <span class="font-weight-bold">
            _DayMonth_
        </span>
        _MonthName_
    </div>
    <ul class="list-unstyled bg-white px-3  py-2 small mb-2">
        <li>
            _EventTitle_
        </li>
    </ul>
</div>
`;