
async function GetNews() {
    showLoaderInsideControl('newsUL');

    var listItems = await CommonFunctions
        .CallWS(CommonFunctions.GetListItems, {
            listName: SiteLists.NewsList.Name,
            itemLimit: 3,
            weburl: `${_spPageContextInfo.siteAbsoluteUrl + SiteLists.NewsList.Path}`,
            orderByField: "Modified"
        });

    var temp = _.map(listItems, function (value, key) {
        var title = CommonFunctions.GetValue(value.Title, value.Title_En);
        //var dateStr = moment(value.Date).format('DD-MMM-YYYY');
        var webAbsoluteUrl = _spPageContextInfo.webAbsoluteUrl;
        if (webAbsoluteUrl.toLowerCase().indexOf("ar") == -1 && webAbsoluteUrl.toLowerCase().indexOf("en") == -1) {
            webAbsoluteUrl = webAbsoluteUrl + "/en";
        }
        var detailsUrl = webAbsoluteUrl + SiteLists.NewsList.DetailsPage + value.ID;

        return `<li>
            <a onclick="showLoader()" href=${detailsUrl}>
                <div class="media">
                    <div class="border-right mr-3 pr-3 text-center">
                        <h4 class="text-fig-purple-80 mb-0">${moment(value.Created).format('DD')}</h4>
                        <span class="small">${moment(value.Created).format('MMM')}</span>
                    </div>
                    <div class="media-body">
                    ${title}
                    </div>
                </div>
            </a>
        </li>`;


    });
    $("#newsUL").html(temp);
}

async function GetAnnouncements() {
    showLoaderInsideControl('announceUL');


    var listItems = await CommonFunctions
        .CallWS(CommonFunctions.GetListItems, {
            listName: SiteLists.AnnouncementsList.Name,
            itemLimit: 3
            , orderByField: "Date"
            , weburl: `${_spPageContextInfo.siteAbsoluteUrl + SiteLists.AnnouncementsList.Path}`
            //,filter:"substringof('announ',Category)"
        }
        );

    var temp = _.map(listItems, function (value, key) {
        var title = CommonFunctions.GetValue(value.Title, value.Title_En);
        var details = CommonFunctions.GetValue(value.Details_Ar, value.Details_En);
        var dateStr = moment(value.Date).format('DD-MMM-YYYY');
        var webAbsoluteUrl = _spPageContextInfo.webAbsoluteUrl;
        if (webAbsoluteUrl.toLowerCase().indexOf("ar") == -1 && webAbsoluteUrl.toLowerCase().indexOf("en") == -1) {
            webAbsoluteUrl = webAbsoluteUrl + "/en";
        }
        var detailsUrl = webAbsoluteUrl + SiteLists.AnnouncementsList.DetailsPage + value.ID;

        return `<li>
                        <a onclick="showLoader()" href=${detailsUrl}>
                            <span class="text-fig-purple-80 small calendar-text">
                                <svg class="icon icon-fill icon-xs mx-1">
                                    <use xlink:href="#icon-clock"></use>
                                </svg>
                                ${dateStr}
                            </span>
                            ${title}
                         </a>
                   </li>`;


    });
    $("#announceUL").html(temp);
}


async function GetCondolonces() {
    showLoaderInsideControl('condoUL');

    //global var
    condolencesListItems = await CommonFunctions
        .CallWS(CommonFunctions.GetListItems, {
            listName: SiteLists.Condolences.Name
            , itemLimit: 3
            , orderByField: "Date"
            , weburl: `${_spPageContextInfo.siteAbsoluteUrl + SiteLists.Condolences.Path}`
            , filter: "Publish eq 1"
        });

    //<a href=${_spPageContextInfo.webAbsoluteUrl + "/announcements" + "/Pages/AnnouncementsDetails.aspx?id=" + value.ID}>
    var temp = _.map(condolencesListItems, function (value, key) {
        return `<li>
                        <a href="javascript:;" onclick="ShowCondolencesDetails('${value.ID}')">
                            <span class="text-fig-purple-80 small calendar-text">
                                <svg class="icon icon-fill icon-xs mx-1">
                                    <use xlink:href="#icon-clock"></use>
                                </svg>
                                ${moment(value.Date).format('DD-MMM-YYYY')}
                            </span>
                            ${CommonFunctions.GetValue(value.Title, value.Title_En)}
                         </a>
                   </li>`;


    });
    $("#condoUL").html(temp);
}


async function GetCongrats() {
    showLoaderInsideControl('congratsUL');

    //global var
    congratslistItems = await CommonFunctions
        .CallWS(CommonFunctions.GetListItems, {
            listName: SiteLists.Congratulations.Name
            , itemLimit: 3
            , orderByField: "Date"
            , weburl: `${_spPageContextInfo.siteAbsoluteUrl + SiteLists.Congratulations.Path}`
            , filter: "Publish eq 1"
        });
    //<a href=${_spPageContextInfo.webAbsoluteUrl + "/announcements" + "/Pages/AnnouncementsDetails.aspx?id=" + value.ID}>
    var temp = _.map(congratslistItems, function (value, key) {
        return `<li>
                        <a href="javascript:;" onclick="ShowCongratDetails('${value.ID}')">
                            <span class="text-fig-purple-80 small calendar-text">
                                <svg class="icon icon-fill icon-xs mx-1">
                                    <use xlink:href="#icon-clock"></use>
                                </svg>
                                ${moment(value.Date).format('DD-MMM-YYYY')}
                            </span>
                            ${CommonFunctions.GetValue(value.Title, value.Title_En)}
                         </a>
                   </li>`;


    });
    $("#congratsUL").html(temp);
}

async function GetFavoriteLinks() {
    showLoaderInsideControl('favoriteLinksUL', 6);

    var listItems = await CommonFunctions.CallWS(CommonFunctions.GetListItems, {
        listName: SiteLists.FavoriteLinksList.Name
        , itemLimit: 5
        , orderByField: "ShowOrder"
        , orderByAsc: false
        , weburl: `${_spPageContextInfo.siteAbsoluteUrl + SiteLists.FavoriteLinksList.Path}`
    });

    var temp = _.map(listItems, function (value, key) {
        return `<li>
                        <a href=${value.Link.Url} target="_blank">
                            ${CommonFunctions.GetValue(value.Title, value.Title_En)}
                         </a>
                   </li>`;
    });


    $("#favoriteLinksUL").html(temp);
}

async function GetForms() {
    showLoaderInsideControl('formsUL');

    var listItems = await CommonFunctions
        .CallWS(CommonFunctions.GetListItems, {
            listName: SiteLists.Forms.Name,
            itemLimit: 3
            , orderByField: "Created"
            , weburl: `${_spPageContextInfo.siteAbsoluteUrl + SiteLists.Forms.Path}`
            , filter: "Type_En eq 'Form' and Publish eq 1"
        }
        );

    var temp = _.map(listItems, function (value, key) {
        var title = CommonFunctions.GetValue(value.Title_Ar, value.Title_En);
        //var details = CommonFunctions.GetValue(value.Details_Ar, value.Details_En);
        var dateStr = moment(value.Created).format('DD-MMM-YYYY');
        var webAbsoluteUrl = _spPageContextInfo.webAbsoluteUrl;
        if (webAbsoluteUrl.toLowerCase().indexOf("ar") == -1 && webAbsoluteUrl.toLowerCase().indexOf("en") == -1) {
            webAbsoluteUrl = webAbsoluteUrl + "/en";
        }
        var detailsUrl = webAbsoluteUrl + SiteLists.Forms.DetailsPage + value.ID;

        return `<li>
                        <a onclick="showLoader()" href=${detailsUrl}>
                            <span class="text-fig-purple-80 small calendar-text">
                                <svg class="icon icon-fill icon-xs mx-1">
                                    <use xlink:href="#icon-clock"></use>
                                </svg>
                                ${dateStr}
                            </span>
                            ${title}
                         </a>
                   </li>`;


    });
    $("#formsUL").html(temp);
}

async function GetProcedures() {
    showLoaderInsideControl('proceduresUL');

    var listItems = await CommonFunctions
        .CallWS(CommonFunctions.GetListItems, {
            listName: SiteLists.Procedures.Name,
            itemLimit: 3
            , orderByField: "Created"
            , weburl: `${_spPageContextInfo.siteAbsoluteUrl + SiteLists.Procedures.Path}`
            , filter: "Type_En eq 'Procedure' and Publish eq 1"
        }
        );

    var temp = _.map(listItems, function (value, key) {
        var title = CommonFunctions.GetValue(value.Title_Ar, value.Title_En);
        //var details = CommonFunctions.GetValue(value.Details_Ar, value.Details_En);
        var dateStr = moment(value.Created).format('DD-MMM-YYYY');
        var webAbsoluteUrl = _spPageContextInfo.webAbsoluteUrl;
        if (webAbsoluteUrl.toLowerCase().indexOf("ar") == -1 && webAbsoluteUrl.toLowerCase().indexOf("en") == -1) {
            webAbsoluteUrl = webAbsoluteUrl + "/en";
        }
        var detailsUrl = webAbsoluteUrl + SiteLists.Procedures.DetailsPage + value.ID;

        return `<li>
                        <a onclick="showLoader()" href=${detailsUrl}>
                            <span class="text-fig-purple-80 small calendar-text">
                                <svg class="icon icon-fill icon-xs mx-1">
                                    <use xlink:href="#icon-clock"></use>
                                </svg>
                                ${dateStr}
                            </span>
                            ${title}
                         </a>
                   </li>`;


    });
    $("#proceduresUL").html(temp);
}

async function GetBanners() {
    showLoaderInsideControl('divBanner');
    var filter = "$filter=Publish eq 1 ";
    if (_spPageContextInfo.currentCultureLCID == 1025) {
        filter += "and LanguageType eq 'Arabic' "
    } else {
        filter += "and LanguageType eq 'English' "
    }
    var selectfields = "$select=FileRef/FileRef";
    //var requestUrl = `${_spPageContextInfo.siteAbsoluteUrl + SiteLists.Banners.Path}/_api/web/lists/getbytitle('${SiteLists.Banners.Name}')/Items?${selectfields}&${filter}`;

    AjaxRequest(
        ShowBanner,  //fnSuccess
        null,        //fnBeforeSend
        null,        //fnComplete
        emptyControlHtml('divBanner'),//emptyControlHtml('divBanner'),//fnError
        {
            listName: SiteLists.Banners.Name,
            listPath: SiteLists.Banners.Path,
            selectFields: selectfields,
            filter: filter,

        });

    //$.ajax({
    //    url: requestUrl,
    //    type: "GET",
    //    headers: { "accept": "application/json;odata=verbose" },
    //    success: function (data) {
    //        if (data && data.d && data.d.results) {
    //            // TODO: handle the data
    //            console.log(data.d.results[0].FileRef);
    //            var temp = _.map(data.d.results, function (value, key) {
    //                //var details = CommonFunctions.GetValue(value.Details_Ar, value.Details_En);

    //                return ` <img class="mySlides" src="${value.FileRef}" style="width:100%">`;
    //            });
    //            $("#divBanner").html(temp);

    //            /////
    //            carousel();
    //        }
    //    },
    //    error: function (xhr) {
    //        $("#divBanner").html('');
    //        console.log('banner error');
    //        console.log(xhr.status + ': ' + xhr.statusText);
    //    }
    //});

}

function ShowBanner(data) {
    if (data && data.d && data.d.results) {
        // TODO: handle the data  
        console.log(data.d.results[0].FileRef);
        var temp = _.map(data.d.results, function (value, key) {
            return ` <img class="mySlides" src="${value.FileRef}" style="width:100%">`;
        });
        $("#divBanner").html(temp);

        /////
        carousel();
    } else {
        $("#divBanner").html('');
    }
}



$(document).ready(async function () {


    showLoaderInsideControl('newsUL');
    showLoaderInsideControl('announceUL');
    showLoaderInsideControl('condoUL');
    showLoaderInsideControl('congratsUL');
    showLoaderInsideControl('favoriteLinksUL', 6);
    showLoaderInsideControl('formsUL');
    showLoaderInsideControl('proceduresUL');
    showLoaderInsideControl('divBanner');
    //////////////////////

 

    GetBanners();
    GetNews();
    GetAnnouncements();
    GetCondolonces();
    GetCongrats();
    GetFavoriteLinks();
    GetForms();
    GetProcedures();


    setTitleResourse('LatestNewsTitle', 'divLatestNews');
    setTitleResourse('Announcements', 'divAnnouncements');
    setTitleResourse('FavoriteLinks', 'divFavoriteLinks');
    setTitleResourse('AlinmaCalendar', 'divAlinmaCalendar');
    setTitleResourse('Congratulations', 'divCongratulations');
    setTitleResourse('Condolences', 'divCondolences');
    setTitleResourse('Modules', 'divForms');
    setTitleResourse('Procedures', 'divProcedures');
    setTitleResourse('RequestCenter', 'divRequestCenter');
    SetClassAttribute('card-headerLink', 'title', GetResourseValue('More'));

});


