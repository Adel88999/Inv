const resourseEn =
{
    News: 'News',
    LatestNewsTitle: 'Latest News',
    Announcements: 'Announcements',
    FavoriteLinks: 'Favorite Links',
    AlinmaCalendar: 'Alinma Calendar',
    Congratulations: 'Congratulations',
    Congratulation: 'Congratulation',
    Condolences: 'Condolences',
    Condolence: 'Condolence',
    Modules: 'Forms',
    Procedures: 'Procedures',
    RequestCenter: 'Request Center', 	//divRequestCenter	
    GroupSelector: 'Group / Sector / Management',   //lblGrouupSelector
    AICAlinmaCalendar: 'AIC Alinma Calendar',    //divAICAlinmaCalendar,
    Welcome: 'Welcome',
    Next: 'Next',
    Previous: 'Previous',
    ItemsPerPage: 'Items Per Page',
    Close: 'Close',
    More: 'More...',
    NoData:'No Data available ... ',
    Download: 'Download',
    FormHeaderTitle: 'Form Name',
    ProcedureHeaderTitle: 'Procedure Name',
    FormHeaderDetails: 'Forms and additional requirements',
    ProcedureHeaderDetails: 'Procedures and additional requirements',
    CommonErrorTryLater: 'Error happened, Please try later',
    ErrorWhileLoading: 'Error happened while loading data',
    emptyTable: "No data available in table",
    LastLogin: "Last Login : ",
    EmployeeOffers: "Employee Offers",
    AlInmaEmployeeOffers: "AlInma Employee Offers",
    EmployeeOffersDetails: "Employees Offer Details",
    OffersCategories: "Offers Categories",
    KindlySelect: "Kindly Select",
    GallaryTitle: "Gallary Images",



    // DataTableLocalization start
  
    info: "Showing _START_ to _END_ of _TOTAL_ entries",
    infoEmpty: "Showing 0 to 0 of 0 entries",
    infoFiltered: "(filtered from _MAX_ total entries)",
    lengthMenu: "Show _MENU_ entries",
    loadingRecords: "Loading...",
    processing: "processing",
    search: "Search:",
    eroRecords: "No matching records found",
    // DataTableLocalization end

}