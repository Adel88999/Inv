﻿

async function GetNews() {
    showLoaderInsideControl('DivInnerLoader', 1);

    var listItems = await CommonFunctions
        .CallWS(CommonFunctions.GetListItems, {
            listName: SiteLists.NewsList.Name
            , itemLimit: 1000000
            , orderByField: "Date"
            , weburl: `${_spPageContextInfo.siteAbsoluteUrl + SiteLists.NewsList.Path}`
            //,filter:"Publish eq 'false'"
        });

    var tempTableTrs = _.map(listItems, function (value, key) {
        var title = CommonFunctions.GetValue(value.Title, value.Title_En);
        //var details = CommonFunctions.GetValue(value.Details_Ar, value.Details_En);
        var dateStr = moment(value.Date).format('DD-MMM-YYYY');
        var detailsUrl = _spPageContextInfo.webAbsoluteUrl + "/Pages/NewsDetails.aspx?DetailsId=" + value.ID;
        return `<tr>
                    <td>
                        <a onclick="showLoader()" href=${detailsUrl}>
                        <span class="small calendar-text">
                          <svg class="icon icon-fill icon-xs mx-1">
                            <use xlink:href="#icon-clock"></use>
                          </svg>
                          <label>${dateStr}</label>
                        </span>
                        ${title}
                      </a>
                    </td>
                </tr>`;

    });

    $("#tblDataList").find('tbody').append(tempTableTrs);
    if (_spPageContextInfo.currentCultureLCID == 1025) {
        $('#tblDataList').DataTable({
            "language":
                DataTableLocalizationAr
        });
    } else {
        $('#tblDataList').DataTable();
    }

    $("#DivInnerLoader").html('');
    $("#tblDataList_previous").text(GetResourseValue('Previous'));
    $("#tblDataList_next").text(GetResourseValue('Next'));
}
function ShowDetails(itemId) {
    showLoader();
    window.location.href = _spPageContextInfo.webAbsoluteUrl + "/Pages/AnnouncementDetails.aspx?id=" + itemId
}

$(document).ready(async function () {

    GetNews();
    setTitleResourse('News', 'divInnerTitle');

});