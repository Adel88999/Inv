const resourseAr =
{
    News: ' الأخبار',    		//divLatestNews
    LatestNewsTitle: 'آخر الأخبار',    		//divLatestNews
    Announcements: 'التعاميم',    			//divAnnouncements
    FavoriteLinks: 'الروابط المفضلة',		//divFavoriteLinks
    AlinmaCalendar: 'تقويم الإنماء',			//divAlinmaCalendar
    Congratulations: 'التهاني',   			//divCongratulations
    Congratulation: 'تهنئه',
    Condolences: 'التعازي',					//divCondolences
    Condolence: 'تعزيه',
    Modules: 'النماذج',						//divModules
    Procedures: 'الإجراءات', 					//divProcedures
    RequestCenter: 'مركز الخدمات', 	//divRequestCenter
    GroupSelector: 'مجموعة / قطاع / إدارة',   //lblGrouupSelector
    AICAlinmaCalendar: 'تقويم الإنماء للاستثمار',    //divAICAlinmaCalendar,
    Welcome: 'مرحباً بالزميل',
    Search: 'بحث',
    Next: 'التالي',
    Previous: 'السابق',
    ItemsPerPage: 'عدد العناصر بالصفحه',
    SelectItemFirst: 'يرجي إختيار عنصر لإظهار التفاصيل',
    Close: 'إغلاق',
    More: 'المزيد...',
    NoData: 'لا توجد بيانات متاحه ...',
    Download: 'تحميل',
    FormHeaderTitle: 'إسم النموذج',
    ProcedureHeaderTitle: 'إسم الإجراء',
    FormHeaderDetails: 'النماذج والمتطلبات الإضافية',
    ProcedureHeaderDetails: 'الإجراءات والمتطلبات الإضافية',
    CommonErrorTryLater: 'حدث خطأ يرجي المحاولة لاحقا',
    ErrorWhileLoading: 'حدث خطأ أثناء تحميل البيانات',
    emptyTable: "لم يعثر على أية سجلات",
    LastLogin: "اخر تسجيل الدخول : ",
    EmployeeOffers: "عروض منسوبي المصرف",
    EmployeeOffersDetails: "تفاصيل عروض منسوبي المصرف",
    AlInmaEmployeeOffers: "عروض منسوبي مصرف الإنماء",
    OffersCategories: "فئات العروض",
    KindlySelect: "يرجي الاختيار",
    GallaryTitle: "معرض الصور",


    // DataTableLocalization start

    info: "إظهار _START_ إلى _END_ من أصل _TOTAL_ مدخل",
    infoEmpty: "يعرض 0 إلى 0 من أصل 0 سجل",
    infoFiltered: "(منتقاة من مجموع _MAX_ مُدخل)",
    lengthMenu: "أظهر _MENU_ مدخلات",
    loadingRecords: "جارٍ التحميل...",
    processing: "جارٍ التحميل...",
    search: "ابحث:",
    eroRecords: "لم يتم العثور على سجلات مطابقة",
    // DataTableLocalization end

}
