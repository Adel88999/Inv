

function getPageList(totalPages, page, maxLength) {
    function range(start, end) {
        return Array.from(Array(end - start + 1), (_, i) => i + start);
    }

    var sideWidth = maxLength < 9 ? 1 : 2;
    var leftWidth = (maxLength - sideWidth * 2 - 3) >> 1;
    var rightWidth = (maxLength - sideWidth * 2 - 3) >> 1;

    if (totalPages <= maxLength) {
        return range(1, totalPages);
    }

    if (page <= maxLength - sideWidth - 1 - rightWidth) {
        return range(1, maxLength - sideWidth - 1).concat(0, range(totalPages - sideWidth + 1, totalPages));
    }

    if (page >= totalPages - sideWidth - 1 - rightWidth) {
        return range(1, sideWidth).concat(0, range(totalPages - sideWidth - 1 - rightWidth - leftWidth, totalPages));
    }

    return range(1, sideWidth).concat(0, range(page - leftWidth, page + rightWidth), 0, range(totalPages - sideWidth + 1, totalPages));
}

function showPage(whichPage, _numberOfItems, _limitPerPage, _totalPages, _CustomPaginationSize) {
    if (_numberOfItems) {
        numberOfItems = _numberOfItems;
    }
    if (_totalPages) {
        totalPages = _totalPages;
    }
    if (_CustomPaginationSize) {
        CustomPaginationSize = _CustomPaginationSize;
    }
    //
    if (whichPage < 1 || whichPage > totalPages) return false;

    currentPage = whichPage;

    $(".customCard-content .customCard").hide().slice((currentPage - 1) * limitPerPage, currentPage * limitPerPage).show();

    $(".CustomPagination li").slice(1, -1).remove();

    getPageList(totalPages, currentPage, CustomPaginationSize).forEach(item => {
        $("<li>").addClass("page-item").addClass(item ? "current-page" : "dots")
            .toggleClass("customActive", item === currentPage).append($("<a>").addClass("page-link")
                .attr({ href: "javascript:void(0)" }).text(item || "...")).insertBefore(".customnext-page");
    });

    $(".customprevious-page").toggleClass("customDisable", currentPage === 1);
    $(".customnext-page").toggleClass("customDisable", currentPage === totalPages);
    return true;
}


var numberOfItems; //total count
var limitPerPage; //How many customCard items visible per a page
var totalPages;
var CustomPaginationSize; //How many page elements visible in the CustomPagination
var currentPage;

$(document).ready(function () {
    if (_spPageContextInfo.currentCultureLCID == 1025) {
        moment.locale("ar-sa");
    }
    var previousRes = GetResourseValue("Previous");
    var nextRes = GetResourseValue("Next");
    $(".CustomPagination").append(
        $("<li>").addClass("page-item").addClass("customprevious-page").append($("<a>")
            .addClass("page-link")
            .attr({ href: "javascript:void(0)" })
            .text(previousRes)),
        $("<li>").addClass("page-item").addClass("customnext-page").append($("<a>").addClass("page-link")
            .attr({ href: "javascript:void(0)" }).text(nextRes))
    );

    $(document).on("click", ".CustomPagination li.current-page:not(.customActive)", function () {
        return showPage(+$(this).text());
    });

    $(".customnext-page").on("click", function () {
        return showPage(currentPage + 1);
    });

    $(".customprevious-page").on("click", function () {
        return showPage(currentPage - 1);
    });

    if (_spPageContextInfo.currentCultureLCID == 1025) {
        $(".CustomPagination").attr("dir", "rtl");
    } else {
        $(".CustomPagination").attr("dir", "ltr");
    }
});