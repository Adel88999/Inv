
ListNames = {

    QuickLinksList: "QuickLinks",
    GroupsList: "AIC_Groups",
    NewsList: "AIC_News",
    AnnouncementsList: "AIC_Announcements",
    FavoriteLinksList: "Favorite_Links",
    ImageGalleryList: "ImageGallery",
    Congratulations: "AIC_Congratulations",
    Condolences: "AIC_Condolences",
}

SiteLists = {

    QuickLinksList: {
        Name: "QuickLinks",
        Path: "/ar",
        DetailsPage: ""
    },
    GroupsList: {
        Name: "AIC_Groups",
        Path: "/ar",
        DetailsPage: ""
    },
    NewsList: {
        Name: "AIC_News",
        Path: "/ar/news",
        DetailsPage: "/news/Pages/NewsDetails.aspx?DetailsId="
    },
    AnnouncementsList: {
        Name: "AIC_Announcements",
        Path: "/ar/Announcements",
        DetailsPage: "/announcements/Pages/AnnouncementDetails.aspx?DetailsId="
    },
    FavoriteLinksList: {
        Name: "Favorite_Links",
        Path: "/ar",
        DetailsPage: ""
    },
    ImageGalleryList: {
        Name: "ImageGallery",
        Path: "/ar/Gallery",
        DetailsPage: "/pages/EventsDetails.aspx?folderUrl="
    },
    Congratulations: {
        Name: "AIC_Congratulations",
        Path: "/ar/announcements",
        DetailsPage: ""
    },
    Condolences: {
        Name: "AIC_Condolences",
        Path: "/ar/announcements",
        DetailsPage: ""
    },
    Procedures: {
        Name: "Procedures-Forms",
        Path: "/ar/",
        DetailsPage: "/Pages/FormDetails.aspx?FormTypeId=2&DetailsId="
    },
    Forms: {
        Name: "Procedures-Forms",
        Path: "/ar/",
        DetailsPage: "/Pages/FormDetails.aspx?FormTypeId=1&DetailsId="
    },
    Banners: {
        Name: "Banners",
        Path: "/ar/",
        DetailsPage: ""
    },
    EmployeesOffers: {
        Name: "EmployeesOffers",
        Path: "/ar/",
        DetailsPage: "/Pages/EmployeesOfferDetails.aspx?DetailsId="
    },
    OffersLogo: {
        Name: "OffersLogo",
        Path: "/ar/",
        DetailsPage: ""
    },
    InvestmentCalendar: {
        Name: "InvestmentCalendar",
        Path: "/ar/",
        DetailsPage: ""
    },

}



