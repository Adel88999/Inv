﻿var itemsListTemp = [];
var dataCategories = [];
/*
 * no data check 
 * error check
 * 
 * */
function GetData() {
    showLoaderInsideControl('div_OffersContainer', 1);

    var today = new Date();
    var yyyy = today.getFullYear();
    var mm = today.getMonth() + 1; // Months start at 0!
    var dd = today.getDate();

    if (dd < 10) dd = '0' + dd;
    if (mm < 10) mm = '0' + mm;

    var formattedToday = mm + '/' + dd + '/' + yyyy;

    var filter = "$filter=ExpiredDate gt '" + formattedToday + "'"

    //var filter = "$filter=Publish eq 1 ";

    var selectfields = "$select=Category_Ar,Category_En,Details_Ar,Details_En,Publish,Title_Ar,Title_En,Type_Ar,Type_En,FileRef/FileRef";

    AjaxRequest(
        DrawData,  //fnSuccess
        null,      //fnBeforeSend
        null,      //fnComplete
        null,      //fnError
        {
            listName: SiteLists.EmployeesOffers.Name,
            listPath: SiteLists.EmployeesOffers.Path,
            //filter: filter,
            //selectFields: selectfields,
            loaderDivId: 'div_OffersContainer',
            showEmpty: true,
            showError: true
        });

}


function DrawSection(category, detailsUrl) {
    var offersBoxContainerTemp = offersBoxContainer;
    offersBoxContainerTemp = offersBoxContainerTemp.replace('_OfferCategoryTitle_', category);

    var formCardTemp = formCard;
    var offerBoxTemp = offerBox;

    var formTableBodyTrTemp = '';
    var itemsByCategory = itemsListTemp.filter(function (item) {
        return CommonFunctions.GetValue(item.Category_Ar, item.Category_En) == category
    });
    var trs = _.map(itemsByCategory, function (item, index) {

        return offerBoxTemp.replace('_Title_', CommonFunctions.GetValue(item.Title, item.Title_En))
            .replace('_DetailsURL_', detailsUrl + item.ID)
            .replace('_boxImageURL_', item.Logo.Url)
    });

    offersBoxContainerTemp = offersBoxContainerTemp.replace('_OfferBoxes_', trs.join(''));
    //allCategoriesCards += offersBoxContainerTemp;
    $("#div_OffersContainer").append(offersBoxContainerTemp);
}

function ReDrawData() {
    $("#div_OffersContainer").html('');
    _.map(dataCategories, function (value, key) {
        DrawSection(value, detailsUrl);
    });
}

function DrawData(data) {
    if (data && data.d && data.d.results) {

        itemsListTemp = data.d.results;
        var allCategoriesCards = []; //all cats filled each loop

        dataCategories = [];

        if (_spPageContextInfo.currentCultureLCID == 1025) {
            dataCategories = Array.from(new Set(itemsListTemp.map(function (item) { return item.Category_Ar })));
        } else {
            dataCategories = Array.from(new Set(itemsListTemp.map(function (item) { return item.Category_En })));
        }

        if (dataCategories && dataCategories.length > 0 && dataCategories[0]) {
            $("#div_OffersContainer").html('');
            var dataCategorieOptions = _.map(dataCategories, function (value, key) {
                
                DrawSection(value, detailsUrl);
                //$('#ddlCategories').append($('<option>', {
                //    value: value,
                //    text: value
                //}));
                return `<option value="${value}">${value}</option>`
            });

            $("#ddlCategories").html(`<option value="-1">${GetResourseValue('KindlySelect')}</option>` + dataCategorieOptions.join(''))
           
        } else {
            var noDataDiv = divWarning.replace('_message_', GetResourseValue('NoData'))
            $("#div_OffersContainer").html(noDataDiv);
        }
    }
}

function FilterData() {
    var selectedCategory = $('#ddlCategories').val();
    $("#div_OffersContainer").html('');
    if (selectedCategory == "-1") {
        ReDrawData();
    }
    else {
        DrawSection(selectedCategory)
    }
}

var detailsUrl = '';

$(document).ready(async function () {
    setTitleResourse('EmployeeOffers', 'divInnerTitle');
    setTitleResourse('OffersCategories', 'spanCategoryTitle');
    setTitleResourse('AlInmaEmployeeOffers', 'linkAlInmaPortal');
    
    var webAbsoluteUrl = _spPageContextInfo.webAbsoluteUrl;
    if (webAbsoluteUrl.toLowerCase().indexOf("ar") == -1 && webAbsoluteUrl.toLowerCase().indexOf("en") == -1) {
        webAbsoluteUrl = webAbsoluteUrl + "/en";
    }
    detailsUrl = webAbsoluteUrl + SiteLists.EmployeesOffers.DetailsPage;

    GetData();
    $('#ddlCategories').on('change', FilterData);


});