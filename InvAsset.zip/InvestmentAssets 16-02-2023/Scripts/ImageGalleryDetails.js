// import "./CommonFunctions";
// import _ from "./lodash.min.js";
// import { $pnp } from "./pnp.min.js";
$(document).ready(async function(){
    let GetGalleryDetails=async function (){
  
      //  var listItems=  await CommonFunctions.GetListItems({listName:ListNames.GroupsList,weburl:_spPageContextInfo.siteAbsoluteUrl+"/ar"});

        var listItems=  await CommonFunctions.CallWS(CommonFunctions.GetFolderImages,{listName:getParameterByName('folderUrl')});
        var temp=_.map(listItems, function(value, key) {
         return `<div class="card" style="width: 18rem;">
                     <a href="${value.ServerRelativeUrl}" data-fancybox="group">
                     <img src="${value.ServerRelativeUrl}" class="card-img-top" alt="">
                     </a>
                     <div class="card-body">
                     </div>
                  </div>`;
                });


        $("#ImagesList").html(temp);
        $('[data-fancybox]').fancybox({loop: true});
    }
     GetGalleryDetails();
});
 


/*
$pnp.sp.web
   .getFolderByServerRelativeUrl(_spPageContextInfo.webServerRelativeUrl + '/ImageGallery/Event1') // Here comes a folder/subfolder path
   .files
   .expand('Files/ListItemAllFields') // For Metadata extraction
   .select('Title,Name,ServerRelativeUrl')              // Fields to retrieve
   .get().then(function(item) {
      console.log(item);
   });
*/