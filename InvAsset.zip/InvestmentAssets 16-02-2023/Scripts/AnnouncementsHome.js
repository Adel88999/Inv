﻿
async function GetAnnouncements() {
    showLoaderInsideControl('DivInnerLoader', 1);

    var listItems = await CommonFunctions
        .CallWS(CommonFunctions.GetListItems, {
            listName: ListNames.AnnouncementsList
            , itemLimit: 1000000
            , orderByField: "Date"
            , weburl: `${_spPageContextInfo.siteAbsoluteUrl + "/ar/announcements"}`
            //,filter:"Publish eq 'false'"
        });

    var tempTRCards = _.map(listItems, function (value, key) {
        return `<tr><td><div class="customCard">
                            <div class="customCard-image"><img src="${announcementTempPath}" width="100%" alt=""></div>
                            <div class="customCard-info">
                                    <h3> ${CommonFunctions.GetValue(value.Title, value.Title_En)}</h3>
                               <p>${moment(value.Date).format('DD-MMM-YYYY')}</p>
                            </div>
                            <div class="card bg-primary"></div>
                        </div></td>
                </tr>
`;

    });
    /* - ${value.Date.split('T')[0]}*/
    //<a href="javascript:;" onclick="ShowDetails('${value.Id}')">
    var tempTableTrs = _.map(listItems, function (value, key) {
        var title = CommonFunctions.GetValue(value.Title, value.Title_En);
        //var details = CommonFunctions.GetValue(value.Details_Ar, value.Details_En);
        var dateStr = moment(value.Date).format('DD-MMM-YYYY');
        var detailsUrl = _spPageContextInfo.webAbsoluteUrl + "/Pages/AnnouncementDetails.aspx?DetailsId=" + value.ID;
        return `<tr>
                    <td>
                        <a onclick="showLoader()" href=${detailsUrl}>
                        <span class="small calendar-text">
                          <svg class="icon icon-fill icon-xs mx-1">
                            <use xlink:href="#icon-clock"></use>
                          </svg>
                          <label>${dateStr}</label>
                        </span>
                        ${title}
                      </a>
                    </td>
                </tr>`;

    });

    $("#tblDataList").find('tbody').append(tempTableTrs);
    //$("#tblDataList").find('tbody').append(tempTRCards);
    //$("#tblDataList").DataTable();
    if (_spPageContextInfo.currentCultureLCID == 1025) {
        $('#tblDataList').DataTable({
            "language":
                DataTableLocalizationAr
        });
       // $('.card tbody tr').css('float', 'right')
    } else {
        $('#tblDataList').DataTable();
       // $('.card tbody tr').css('float', 'left')
    }

    $("#DivInnerLoader").html('');
    $("#tblDataList_previous").text(GetResourseValue('Previous'));
    $("#tblDataList_next").text(GetResourseValue('Next'));
}
function ShowDetails(itemId) {
    showLoader();
    window.location.href = _spPageContextInfo.webAbsoluteUrl + "/Pages/AnnouncementDetails.aspx?id=" + itemId
}

$(document).ready(async function () {

    GetAnnouncements();
    setTitleResourse('Announcements', 'divInnerTitle');

});