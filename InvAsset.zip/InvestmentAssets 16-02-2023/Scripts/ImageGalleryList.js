
async function GetGalleries() {


    var listItems = await CommonFunctions.CallWS(CommonFunctions.GetRootFolders,
        {
            listName: SiteLists.ImageGalleryList.Name//ListNames.ImageGalleryList
            , filter: "Name ne 'Forms'"
            , weburl: `${_spPageContextInfo.siteAbsoluteUrl + SiteLists.ImageGalleryList.Path}`
        });
    var temp = _.map(listItems, function (value, key) {
        return `<div>
                <a href="${_spPageContextInfo.webServerRelativeUrl + SiteLists.ImageGalleryList.DetailsPage + value.ServerRelativeUrl}">
                            ${CommonFunctions.GetValue(value.Name, value.Name)}
                            </a>
                        </div>`;

    });
    $("#ImageGalleryList").html(temp);
};

$(document).ready(function () {

    setTitleResourse('GallaryTitle', 'divTitle');

    GetGalleries();
})


