﻿


var itemsListTemp = [];
var dataCategories = [];
/*
 * no data check 
 * error check
 * 
 * */
function GetData(detailsItemID) {
    showLoaderInsideControl('divBodyCards', 1);

    var today = new Date();
    var yyyy = today.getFullYear();
    var mm = today.getMonth() + 1; // Months start at 0!
    var dd = today.getDate();

    if (dd < 10) dd = '0' + dd;
    if (mm < 10) mm = '0' + mm;

    var formattedToday = mm + '/' + dd + '/' + yyyy;

    //var filter = "$filter=ExpiredDate gt '" + formattedToday + "'"
    var filter = `$filter= ID eq '${detailsItemID}'`
    //var filter = "$filter=Publish eq 1 ";

    var selectfields = "$select=Category_Ar,Category_En,Details_Ar,Details_En,Publish,Title_Ar,Title_En,Type_Ar,Type_En,FileRef/FileRef";

    AjaxRequest(
        DrawData,  //fnSuccess
        null,      //fnBeforeSend
        null,      //fnComplete
        null,      //fnError
        {
            listName: SiteLists.EmployeesOffers.Name,
            listPath: SiteLists.EmployeesOffers.Path,
            filter: filter,
            //selectFields: selectfields,
            loaderDivId: 'divBodyCards',
            showEmpty: true,
            showError: true
        });

}

function DrawData(data) {
    if (data && data.d && data.d.results) {

        var itemsListTemp = data.d.results;
        if (itemsListTemp[0]) {
            $("#divBodyCards").html('');
            var item = itemsListTemp[0];
            var offersDetailsContainerTemp = offersDetailsContainer;

            offersDetailsContainerTemp = offersDetailsContainerTemp.replace('_OfferTitle_', CommonFunctions.GetValue(item.Title, item.Title_En));
            offersDetailsContainerTemp = offersDetailsContainerTemp.replace('_OfferCategoryTitle_', CommonFunctions.GetValue(item.Category_Ar, item.Category_En));
            offersDetailsContainerTemp = offersDetailsContainerTemp.replace('_ImageURL_', item.Logo.Url);
            offersDetailsContainerTemp = offersDetailsContainerTemp.replace('_Details_', CommonFunctions.GetValue(item.Details_Ar, item.Details_En));
            $("#divBodyCards").html(offersDetailsContainerTemp);
        }
    }
}

$(document).ready(async function () {
    var detailsId = getParameterByName("DetailsId");
    setTitleResourse('EmployeeOffersDetails', 'divTitle');

    GetData(detailsId);
});

