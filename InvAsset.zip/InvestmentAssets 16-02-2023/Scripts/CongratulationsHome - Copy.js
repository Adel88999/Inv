var listItems=[];
async function GetCongrats() {
	showLoaderInsideControl('congratsUL');
	if (_spPageContextInfo.currentCultureLCID == 1025) {
		moment.locale("ar-sa");
	}
	listItems = await CommonFunctions
		.CallWS(CommonFunctions.GetListItems, {
			listName: ListNames.Congratulations,
			itemLimit: 10000,
			orderByField: "Date",
			weburl: `${_spPageContextInfo.siteAbsoluteUrl+"/ar/announcements"}`
			//,filter:"Publish eq 'false'"
		});

	/* var temp=_.map(listItems, function(value, key) {
			return `<li>
                                <a href=${_spPageContextInfo.webAbsoluteUrl+"/announcements"+"/Pages/AnnouncementsDetails.aspx?id="+value.ID}>
                                    <span class="small calendar-text">
                                        <s	vg class="icon icon-fill icon-xs mx-1">
                                            <use xlink:href="#icon-clock"></use>
                                        </svg>
                                      ${moment(value.Date).format('DD-MMM-YYYY')}
                                    </span>
                                     ${CommonFunctions.GetValue(value.Title,value.Title_En)}
                                </a>
                            </li>`;
		
       _.map(listItems, function(value, key) {
		$('#tblCongrats').find('tbody').append(`
                                <tr>
                                    <td>
										<a href="${_spPageContextInfo.webAbsoluteUrl+"/announcements"+"/Pages/AnnouncementsDetails.aspx?id="+value.ID}" > ${CommonFunctions.GetValue(value.Title,value.Title_En)}</a>
									</td>
                                    <td>
										${moment(value.Date).format('DD-MMM-YYYY')}
									</td> 
                                </tr>`);
        
                });
				
				
				*/
				
				
       _.map(listItems, function(value, key) {
		$('#tblCongrats').find('tbody').append(`
                                <tr>
                                    <td>
										
                                <a href=${_spPageContextInfo.webAbsoluteUrl+"/announcements"+"/Pages/AnnouncementsDetails.aspx?id="+value.ID}>
                                    <span class="small calendar-text">
                                        <svg class="icon icon-fill icon-xs mx-1">
                                            <use xlink:href="#icon-clock"></use>
                                        </svg>
                                      ${moment(value.Date).format('DD-MMM-YYYY')}
                                    </span>
                                     ${CommonFunctions.GetValue(value.Title,value.Title_En)}
                                </a>
                            
									</td> 
                                </tr>`);
	
	});
	//load datatable
	// $('#tblCongrats').DataTable( {
  // "pageLength": 1,

// } );

	//change table to cards
	// $("#tblCongrats").toggleClass('cards')
	// $("#tblCongrats thead").toggle()
	// $('#tblCongrats_wrapper').removeClass();


// if (_spPageContextInfo.currentCultureLCID == 1025) {
		// $('.cards tbody tr').css('float','right');
	// }else	{
		// $('.cards tbody tr').css('float','left');
	// }

	$("#congratsUL").html('');
	
}

$(document).ready(async function() {

	// showLoader();
	// hideLoader()

	//////////////////////

	GetCongrats();

	setTitleResourse('Congratulations', 'divCongratulationsTitle');
	$("#txtSearch").attr("placeholder", GetResourseValue('Search'));
	
	

});