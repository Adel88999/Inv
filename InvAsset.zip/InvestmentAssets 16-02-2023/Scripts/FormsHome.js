﻿

function GetForms(formTypeId) {
    showLoaderInsideControl('divBodyCards', 1);

    var filter = "";
    if (formTypeId && formTypeId == 2) {
        filter = "$filter=Type_En eq 'Procedure' and Publish eq 1 ";
    } else {
        filter = "$filter=Type_En eq 'Form' and Publish eq 1 ";
    }
    
    //var filter = "$filter=Publish eq 1 ";

    var selectfields = "$select=Category_Ar,Category_En,Details_Ar,Details_En,Publish,Title_Ar,Title_En,Type_Ar,Type_En,FileRef/FileRef";

    AjaxRequest(
        DrawData,  //fnSuccess
        null,      //fnBeforeSend
        null,      //fnComplete
        null,      //fnError
        {
            listName: SiteLists.Forms.Name,
            listPath: SiteLists.Forms.Path,
            filter: filter,
            selectFields: selectfields,
            loaderDivId: 'divBodyCards',
            showEmpty: true,
            showError: true
        });

}

function DrawData(data) {
    if (data && data.d && data.d.results) {

        var itemsList = data.d.results;
        var allCards = '';
        var formCardContainerTemp = formCardContainer;
        var dataCategories = [];
        if (_spPageContextInfo.currentCultureLCID == 1025) {
            dataCategories = Array.from(new Set(itemsList.map(function (item) { return item.Category_Ar })));
        } else {
            dataCategories = Array.from(new Set(itemsList.map(function (item) { return item.Category_En })));
        }

        if (dataCategories && dataCategories.length > 0 && dataCategories[0]) {
            var cardsCounter = 0;
            var formtheadTemp = formTableHead;
            var formTypeId = getParameterByName("FormTypeId");

            if (formTypeId && formTypeId == 2) {
                formtheadTemp = formtheadTemp.replace('_FormHeaderTitle_', GetResourseValue('ProcedureHeaderTitle'));
                formtheadTemp = formtheadTemp.replace('_FormHeaderDetails_', GetResourseValue('ProcedureHeaderDetails'));
            } else {
                formtheadTemp = formtheadTemp.replace('_FormHeaderTitle_', GetResourseValue('FormHeaderTitle'));
                formtheadTemp = formtheadTemp.replace('_FormHeaderDetails_', GetResourseValue('FormHeaderDetails'));
            }
            
            formtheadTemp = formtheadTemp.replace('_FormHeaderDownload_', GetResourseValue('Download'));
            _.map(dataCategories, function (value, key) {
                cardsCounter = cardsCounter + 1;

                var formCardTemp = formCard;
                
                var formTableBodyTrTemp = '';
                var itemsByCategory = itemsList.filter(function (item) {
                    return CommonFunctions.GetValue(item.Category_Ar, item.Category_En) == value
                });
                var trs = _.map(itemsByCategory, function (item, index) {

                    return formsTableBodyTr.replace('_FormName_', CommonFunctions.GetValue(item.Title_Ar, item.Title_En))
                        .replace('_href_', item.FileRef)
                        .replace('_DownloadText_', GetResourseValue('Download'))
                        .replace('_FormDetails_', CommonFunctions.GetValue(item.Details_Ar, item.Details_En))
                        .replace('_fileExtension_', getExtension(item.FileRef));
                });

                formCardTemp = formCardTemp.replace(/\_cardNo_/g, cardsCounter);
                formCardTemp = formCardTemp.replace('_cardHeader_', value);
                formCardTemp = formCardTemp.replace('_thead_', formtheadTemp);
                formCardTemp = formCardTemp.replace('_tbodyTrs_', trs.join(''));
                if (cardsCounter == 1) {
                    formCardTemp = formCardTemp.replace('_CardCollapseClass_', 'collapse show');
                    formCardTemp = formCardTemp.replace('_ariaExpanded_', 'true');
                    formCardTemp = formCardTemp.replace('_CardHeaderBtnClass_', ' ');

                } else {
                    formCardTemp = formCardTemp.replace('_CardCollapseClass_', 'collapse');
                    formCardTemp = formCardTemp.replace('_ariaExpanded_', 'false');
                    formCardTemp = formCardTemp.replace('_CardHeaderBtnClass_', ' collapsed');
                }

                allCards += formCardTemp;
            });
        } else {
            allCards = divWarning.replace('_message_', GetResourseValue('NoData'))
        }
        formCardContainerTemp = formCardContainerTemp.replace('_formCard_', allCards)
        //$.each(data.d.results, function (i, currProgram) {

        //});
        $("#divBodyCards").html(formCardContainerTemp);

    }
}

function ShowDetails(itemId) {
    showLoader();
    window.location.href = _spPageContextInfo.webAbsoluteUrl + "/Pages/AnnouncementDetails.aspx?id=" + itemId
}

$(document).ready(async function () {
    var formTypeId = getParameterByName("FormTypeId");
   
    GetForms(formTypeId);

    if (formTypeId && formTypeId == 2) {
        setTitleResourse('Procedures', 'divTitle');
    } else {
        setTitleResourse('Modules', 'divTitle');
    }


});