﻿var calenderEvents = [];
var datalisttemp = [];
function GenerateCalender(data) {
    var calendarLang = '';
    if (_spPageContextInfo.currentCultureLCID == 1025) {
        //moment.locale("ar-sa");
        calendarLang = 'ar';
    } else {
        calendarLang = 'en';
    }

    if (data && data.d && data.d.results) {
        datalisttemp = data.d.results;
        var detailsListHtml = [];
        $.each(data.d.results, function (index, value) {

            var eventDate = value.EventDate != null ? moment(value.EventDate) : null;
            var eventEndDate = value.EndDate != null ? moment(value.EndDate) : null;

            calenderEvents.push({
                title: value.Title,
                description: value.Description,
                start: eventDate,
                end: eventEndDate,
                //color: value.ThemeColor,
                //allDay: value.IsFullDay,
                location: value.Location
            });

         
            if (index < 4) {
                var detailsItem = calenderDetailsItemContainer.replace('_DayMonth_', moment(eventDate).format('DD'))
                    .replace('_MonthName_', moment(eventDate).format('MMMM'))
                    .replace('_EventTitle_', value.Title)

                detailsListHtml.push(detailsItem);
            }

        })

        $("#divCalenderEventsDetails").html(detailsListHtml.join(''))

    }

    $('#calender').html('')
    $('#calender').fullCalendar('destroy');
    $('#calender').fullCalendar({
        contentHeight: 400,
        defaultDate: new Date(),
        timeFormat: 'h(:mm)a',
        //header: {
        //    left: 'prev,next today',
        //    center: 'title',
        //    right: 'month,basicWeek,basicDay,agenda'
        //},
        eventLimit: true,
        locale: calendarLang,
       
        eventColor: '#378006',
        events: calenderEvents,
        eventClick: function (calEvent, jsEvent, view) {
            $('#calenderModal #eventTitle').text(calEvent.title);
            var $description = $('<div/>');
            if (calEvent.start) {
                $description.append($('<p/>').html('<b>Start:</b>' + calEvent.start.format("DD-MMM-YYYY HH:mm a")));
            }

            if (calEvent.end) {
                $description.append($('<p/>').html('<b>End:</b>' + calEvent.end.format("DD-MMM-YYYY HH:mm a")));
            }

            if (calEvent.description) {
                $description.append($('<p/>').html('<b>Description:</b>' + calEvent.description));
                $('#calenderModal #pDetails').html($description);
            }

            if (calEvent.location) {
                $description.append($('<p/>').html('<b>Location:</b>' + calEvent.location));
            }

            $('#calenderModal #pDetails').empty()
            $('#calenderModal #pDetails').html($description);
            $('#calenderModal').modal('show');
        }
    })
}


$(document).ready(function () {

    var today = new Date();
    var yyyy = today.getFullYear();
    var mm = today.getMonth() + 1; // Months start at 0!
    var dd = today.getDate();

    if (dd < 10) dd = '0' + dd;
    if (mm < 10) mm = '0' + mm;

    var formattedToday = mm + '/' + dd + '/' + yyyy;

    var filter = "$filter=EventDate gt '" + formattedToday + "'"

    AjaxRequest(
        GenerateCalender,  //fnSuccess
        null,      //fnBeforeSend
        null,      //fnComplete
        null,      //fnError
        {
            listName: SiteLists.InvestmentCalendar.Name,
            listPath: SiteLists.InvestmentCalendar.Path,
            filter: filter,
            loaderDivId: 'calender',
            showEmpty: true,
            showError: true
        });

})
